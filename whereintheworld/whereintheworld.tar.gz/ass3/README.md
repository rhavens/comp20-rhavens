===================================
COMP 20 - Web Programming
Assignment 3: Where in the World...
Ryan Havens
===================================

Everything has been correctly implemented. I made to attempt the bonus
challenge, but after doing a decent amount of research I realized I was too worn
out to proceed through another hour of programming, and I might as well reward
myself with a nice nap.

I discussed the assignment briefly with Jason Brillon. 

I spent approximately 10 hours on this assignment between coding, debugging, and
researching APIs.