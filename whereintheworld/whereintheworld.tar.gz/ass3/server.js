// Initialization
var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
var http = require('http');
var validator = require('validator'); // See documentation at https://github.com/chriso/validator.js
var app = express();

var __dirname = path.resolve('.')

// See https://stackoverflow.com/questions/5710358/how-to-get-post-query-in-express-node-js
app.use(bodyParser.json());
// See https://stackoverflow.com/questions/25471856/express-throws-error-as-body-parser-deprecated-undefined-extended
app.use(bodyParser.urlencoded({ extended: true }));

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost/test';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function(error, databaseConnection) {
	db = databaseConnection;
});

app.all('/', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });

app.get('/', function(request, response) {
	response.set('Content-Type', 'text/html');
	var indexPage = '';
	db.collection('locations', function(er, collection) {
		collection.find().sort({'created_at': -1}).toArray(function(err, cursor) {
			if (!err) {
				indexPage += "<!DOCTYPE HTML><html><head><title>Chicken of the Sea</title></head><body><h1>Chicken of the Sea</h1>";
				for (var count = 0; count < cursor.length; count++) {
					indexPage += "<p>Login: " + cursor[count].login + " Lat: " + cursor[count].lat + " Lng: " + cursor[count].lng + " Created at: " + new Date(cursor[count].created_at).toUTCString() + "</p>";
				}
				indexPage += "</body></html>";
				response.send(indexPage);
			} else {
				response.send('<!DOCTYPE HTML><html><head><title>Chicken of the Sea</title></head><body><h1>Whoops, something went terribly wrong!</h1></body></html>');
			}
		});
	});
});

// var curTime = new Date().toUTCString();

app.post('/sendLocation', function(request, response) {
	var login = request.body.login;
	var lat = request.body.lat;
	var lng = request.body.lng;
	var indexPage = "";
	console.log(login + lat + lng);
	if (login != null && lat != null && lng != null) {
		var date = new Date();
		console.log(date);
		var toInsert = {
			"login": login,
			"lat": lat,
			"lng": lng,
			"created_at": date,
		};
		db.collection('locations', function(er, collection) {
			var id = collection.insert(toInsert, function(err, saved) {
				if (err) {
					response.send(500);
					console.log("Something went wrong");
				}
				else {
		db.collection('locations', function(er, collection) {
			collection.find({login:login}).limit(100).toArray(function(err, cursor) {
				if (!err) {
					indexPage += "<!DOCTYPE HTML><html><head><title>Chicken of the Sea</title></head><body>{\"characters\":[],\"students\":[";
					for (var count = 0; count < cursor.length; count++) {
						indexPage += "{\"login\":\"" + cursor[count].login + "\",\"lat\":" + cursor[count].lat + ",\"lng\":" + cursor[count].lng + ",\"created_at\":\"" + new Date(cursor[count].created_at).toUTCString() + "\",\"_id\":\"" + cursor[count]._id + "\"}";
						if ((count + 1) != cursor.length) {
							indexPage += ",";
						}
					}
					indexPage += "]}</body></html>"
					response.send(indexPage);
				} else {
					response.send('<!DOCTYPE HTML><html><head><title>Chicken of the Sea</title></head><body><h1>Whoops, something went terribly wrong!</h1></body></html>');
				}
			});
		});
				}
	   		});
		});
	}
	else {
		response.send('[]');
	}
});

// curl --data "fooditem=coffee" https://obscure-lake-3034.herokuapp.com/

app.get('/locations.json', function(request, response) {
	var indexPage = '';
	var login = request.query.login;
	if (login != null) {
		db.collection('locations', function(er, collection) {
			collection.find({login:login}).sort({'created_at': -1}).toArray(function(err, cursor) {
				if (!err) {
					indexPage += "<!DOCTYPE HTML><html><head><title>Chicken of the Sea</title></head><body>{\"characters\":[],\"students\":[";
					for (var count = 0; count < cursor.length; count++) {
						indexPage += "{\"login\":\"" + cursor[count].login + "\",\"lat\":" + cursor[count].lat + ",\"lng\":" + cursor[count].lng + ",\"created_at\":\"" + new Date(cursor[count].created_at).toUTCString() + "\",\"_id\":\"" + cursor[count]._id + "\"}";
						if ((count + 1) != cursor.length) {
							indexPage += ",";
						}
					}
					indexPage += "]}</body></html>"
					response.send(indexPage);
				} else {
					response.send('<!DOCTYPE HTML><html><head><title>Chicken of the Sea</title></head><body><h1>Whoops, something went terribly wrong!</h1></body></html>');
				}
			});
		});
	}
	else {
		response.send("[]");
	}
});

app.get('/redline.json', function(request, response) {
	response.set('Content-Type', 'text/html');
	var data = '';
	var options = {
		host: 'developer.mbta.com',
		port: 80,
		path: '/lib/rthr/red.json',
		method: 'GET'
	};
	var req = http.request(options, function(res) {
		res.setEncoding('utf8');
		res.on('data', function (chunk) {
			data += chunk;
		});
		res.on('end', function() {
			response.send("<pre style='word-wrap: break-word; white-space: pre-wrap;'>" + data + "</pre>");
		});
	}).on('error', function (error) {
		response.sendStatus(500);
	});

	req.write('data\n');
	req.write('data\n');
});

// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);